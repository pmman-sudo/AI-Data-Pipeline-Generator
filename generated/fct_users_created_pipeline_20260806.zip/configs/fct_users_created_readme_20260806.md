# README: fct_users_created
## Purpose
The `fct_users_created` table is designed to store information about newly created user accounts. It provides a record of when each user was created, their unique identifier, and their associated email address.

## Columns
The table consists of the following columns:
- `user_id` (BIGINT): A unique identifier for each user.
- `created_at` (TIMESTAMP): The timestamp when the user account was created.
- `email` (STRING): The email address associated with the user.

## Owners
The owners of this dataset are:
- Demo

## Tags
This dataset is tagged with:
- Demo

## Lineage
This dataset does not have any upstream lineage.

## Example Usage
To query the total number of users created per day, you can use the following SQL query: