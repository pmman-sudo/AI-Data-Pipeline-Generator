# README: fct_users_created Dataset
## Purpose
The fct_users_created dataset is designed to store information about newly created user accounts. It provides a historical record of user creations, including the user's ID, creation timestamp, and email address.

## Columns
The fct_users_created dataset contains the following columns:
* **user_id (BIGINT)**: Unique identifier for each user.
* **created_at (TIMESTAMP)**: Timestamp when the user account was created.
* **email (STRING)**: Email address associated with the user.

## Owners
The owners of this dataset are:
* **Demo**

## Tags
This dataset is tagged with:
* **Demo**

## Lineage
This dataset has no upstream lineage, meaning it is not derived from any other dataset.

## Example Usage
To query the number of users created per day, you can use the following SQL query: