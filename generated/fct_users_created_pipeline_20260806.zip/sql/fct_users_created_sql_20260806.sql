CREATE TABLE fct_users_created
(
    user_id BIGINT,
    created_at TIMESTAMP,
    email STRING
);

INSERT INTO fct_users_created (user_id, created_at, email)
SELECT 
    c.customer_id AS user_id,
    c.created_at,
    c.email
FROM 
    raw_customers c
WHERE 
    c.created_at IS NOT NULL
    AND c.email IS NOT NULL;