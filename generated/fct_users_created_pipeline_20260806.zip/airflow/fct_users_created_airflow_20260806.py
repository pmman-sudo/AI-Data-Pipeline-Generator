from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.transfers.redshift import RedshiftSQLOperator
from airflow.utils.log import LoggingMixin
from structlog import get_logger

LOGGER = get_logger()

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def create_fct_users_created(**kwargs):
    """
    Create fct_users_created table.
    
    :param kwargs: Airflow context
    """
    try:
        LOGGER.info("Creating fct_users_created table")
        create_table_sql = """
            CREATE TABLE IF NOT EXISTS fct_users_created (
                user_id BIGINT,
                created_at TIMESTAMP,
                email STRING
            );
        """
        RedshiftSQLOperator(task_id='create_fct_users_created', sql=create_table_sql).execute(kwargs)
        LOGGER.info("fct_users_created table created successfully")
    except Exception as e:
        LOGGER.error(f"Error creating fct_users_created table: {str(e)}")
        raise

def load_fct_users_created(**kwargs):
    """
    Load data into fct_users_created table.
    
    :param kwargs: Airflow context
    """
    try:
        LOGGER.info("Loading data into fct_users_created table")
        load_data_sql = """
            INSERT INTO fct_users_created (user_id, created_at, email)
            SELECT user_id, created_at, email
            FROM raw_customers;
        """
        RedshiftSQLOperator(task_id='load_fct_users_created', sql=load_data_sql).execute(kwargs)
        LOGGER.info("Data loaded into fct_users_created table successfully")
    except Exception as e:
        LOGGER.error(f"Error loading data into fct_users_created table: {str(e)}")
        raise

with DAG(
    'fct_users_created',
    default_args=default_args,
    description='A DAG to create and load fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    tags=['Demo'],
) as dag:
    create_fct_users_created_task = PythonOperator(
        task_id='create_fct_users_created',
        python_callable=create_fct_users_created,
    )
    load_fct_users_created_task = PythonOperator(
        task_id='load_fct_users_created',
        python_callable=load_fct_users_created,
    )
    create_fct_users_created_task >> load_fct_users_created_task