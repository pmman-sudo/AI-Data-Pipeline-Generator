from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.transfers.redshift import RedshiftOperator
from airflow.utils.dates import days_ago
import logging

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(seconds=30),
}

def create_fct_users_created(**kwargs):
    """
    Creates the fct_users_created table in Redshift.
    
    :param kwargs: Airflow context
    :return: None
    """
    try:
        logging.info('Creating fct_users_created table')
        redshift_conn = kwargs['ti'].xcom_pull(key='redshift_conn')
        query = """
            CREATE TABLE IF NOT EXISTS fct_users_created (
                user_id BIGINT,
                created_at TIMESTAMP,
                email STRING
            );
        """
        RedshiftOperator(
            task_id='create_fct_users_created',
            conn_id=redshift_conn,
            sql=query
        ).execute(kwargs['context'])
        logging.info('fct_users_created table created successfully')
    except Exception as e:
        logging.error(f'Error creating fct_users_created table: {e}')
        raise

def load_fct_users_created(**kwargs):
    """
    Loads data into the fct_users_created table in Redshift.
    
    :param kwargs: Airflow context
    :return: None
    """
    try:
        logging.info('Loading data into fct_users_created table')
        redshift_conn = kwargs['ti'].xcom_pull(key='redshift_conn')
        query = """
            INSERT INTO fct_users_created (user_id, created_at, email)
            SELECT user_id, created_at, email
            FROM raw_customers;
        """
        RedshiftOperator(
            task_id='load_fct_users_created',
            conn_id=redshift_conn,
            sql=query
        ).execute(kwargs['context'])
        logging.info('Data loaded into fct_users_created table successfully')
    except Exception as e:
        logging.error(f'Error loading data into fct_users_created table: {e}')
        raise

with DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create and load the fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo'],
) as dag:
    create_fct_users_created_task = PythonOperator(
        task_id='create_fct_users_created',
        python_callable=create_fct_users_created,
    )
    load_fct_users_created_task = PythonOperator(
        task_id='load_fct_users_created',
        python_callable=load_fct_users_created,
    )
    create_fct_users_created_task >> load_fct_users_created_task