{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    schema = 'public',
    tags = ['Demo']
  )
}}

WITH 
-- Extracting table names from upstream dependencies
raw_orders AS (
  SELECT * FROM {{ ref('raw_orders') }}
),
raw_customers AS (
  SELECT * FROM {{ ref('raw_customers') }}
)

-- Creating the fct_users_created table
SELECT 
  -- Assuming user_id is an integer in the source tables, cast to BIGINT
  CAST(coalesce(rc.customer_id, ro.customer_id) AS BIGINT) AS user_id,
  -- Assuming created_at is a timestamp in the source tables, cast to TIMESTAMP
  CAST(COALESCE(rc.created_at, ro.created_at) AS TIMESTAMP) AS created_at,
  -- Assuming email is a string in the source tables, cast to STRING
  CAST(COALESCE(rc.email, ro.email) AS STRING) AS email
FROM 
  raw_customers rc
  FULL OUTER JOIN raw_orders ro 
  ON rc.customer_id = ro.customer_id