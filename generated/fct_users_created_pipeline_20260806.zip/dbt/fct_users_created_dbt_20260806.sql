{{
    config(
        materialized = 'table',
        aliases = ['fct_users_created'],
        tags = ['Demo'],
        owner = 'Demo'
    )
}}

WITH 
-- Extracting upstream dependencies from the metadata
raw_customers AS (
    SELECT * FROM {{ ref('raw_customers') }}
),
raw_orders AS (
    SELECT * FROM {{ ref('raw_orders') }}
)

-- Creating the fct_users_created table with the required columns
SELECT 
    -- Assuming user_id is of type BIGINT
    CAST(rc.user_id AS BIGINT) AS user_id,
    -- Assuming created_at is of type TIMESTAMP
    CAST(rc.created_at AS TIMESTAMP) AS created_at,
    -- Assuming email is of type STRING
    CAST(rc.email AS STRING) AS email
FROM 
    raw_customers rc
LEFT JOIN 
    raw_orders ro ON rc.user_id = ro.user_id