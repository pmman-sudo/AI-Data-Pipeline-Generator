# Airflow Pipeline for fct_users_created dataset

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.emr import EmrCreateJobFlowOperator, EmrAddStepsOperator, EmrTerminateJobFlowOperator
from airflow.providers.amazon.aws.sensors.emr import EmrJobFlowSensor
from airflow.utils.dates import days_ago

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Define the DAG
dag = DAG(
    'fct_users_created',
    default_args=default_args,
    description='Airflow pipeline for fct_users_created dataset',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo'],
)

# Define the tasks
t1 = BashOperator(
    task_id='create_database',
    bash_command='aws s3 cp s3://demo-bucket/scripts/create_database.sql /tmp/create_database.sql && aws Athena execute-_query --query-string=file:///tmp/create_database.sql --result-configuration OutputLocation=s3://demo-bucket/queries/',
    dag=dag,
)

t2 = BashOperator(
    task_id='create_table',
    bash_command='aws s3 cp s3://demo-bucket/scripts/create_table.sql /tmp/create_table.sql && aws Athena execute-query --query-string=file:///tmp/create_table.sql --result-configuration OutputLocation=s3://demo-bucket/queries/',
    dag=dag,
)

t3 = PythonOperator(
    task_id='load_data',
    python_callable=load_data,
    dag=dag,
)

t4 = EmrCreateJobFlowOperator(
    task_id='create_emr_cluster',
    job_flow_id='fct_users_created_cluster',
    aws_conn_id='aws_default',
    emr_cluster={
        'Name': 'fct_users_created_cluster',
        'LogUri': 's3://demo-bucket/logs/',
        'ReleaseLabel': 'emr-6.3.0',
        'Instances': {
            'MasterInstanceType': 'm5.xlarge',
            'SlaveInstanceType': 'm5.xlarge',
            'InstanceCount': 2,
            'Ec2KeyName': 'demo-key',
        },
        'Applications': [
            {'Name': 'Hadoop'},
            {'Name': 'Spark'},
        ],
        'Configurations': [
            {
                'Classification': 'spark',
                'Properties': {
                    'spark.executor.memory': '2g',
                },
            },
        ],
    },
    dag=dag,
)

t5 = EmrAddStepsOperator(
    task_id='add_emr_steps',
    job_flow_id='fct_users_created_cluster',
    aws_conn_id='aws_default',
    steps=[
        {
            'Name': 'Transform data',
            'HadoopJarStep': {
                'Jar': 'command-runner.jar',
                'Args': [
                    'spark-submit',
                    '--deploy-mode',
                    'cluster',
                    '--master',
                    'yarn',
                    '--class',
                    'TransformData',
                    's3://demo-bucket/jars/transform-data.jar',
                ],
            },
        },
    ],
    dag=dag,
)

t6 = EmrJobFlowSensor(
    task_id='wait_for_emr_cluster',
    job_flow_id='fct_users_created_cluster',
    aws_conn_id='aws_default',
    timeout=18 * 60 * 60,  # 18 hours
    dag=dag,
)

t7 = EmrTerminateJobFlowOperator(
    task_id='terminate_emr_cluster',
    job_flow_id='fct_users_created_cluster',
    aws_conn_id='aws_default',
    dag=dag,
)

# Define the dependencies
t1 >> t2 >> t3 >> t4 >> t5 >> t6 >> t7

# Load data function
def load_data(**kwargs):
    import pandas as pd
    from sqlalchemy import create_engine

    # Load data from source
    data = pd.read_csv('s3://demo-bucket/data/fct_users_created.csv')

    # Transform data
    data['created_at'] = pd.to_datetime(data['created_at'])

    # Load data into destination
    engine = create_engine('postgresql://user:password@host:port/dbname')
    data.to_sql('fct_users_created', engine, if_exists='replace', index=False)

# YAML configuration
config = """
---
fct_users_created:
  description: Airflow pipeline for fct_users_created dataset
  schedule_interval: '0 0 * * *'
  start_date: '2023-01-01'
  owners:
    - Demo
  tags:
    - Demo
  upstream_lineage: None
"""

# IAM policy
policy = """
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ],
      "Resource": "arn:aws:s3:::demo-bucket/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "athena:GetQueryExecution",
        "athena:GetQueryResults",
        "athena:StartQueryExecution"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "emr:CreateCluster",
        "emr:ModifyCluster",
        "emr:DescribeCluster",
        "emr:ListClusters",
        "emr:TerminateCluster"
      ],
      "Resource": "*"
    }
  ]
}
"""

# README documentation
readme = """
# fct_users_created dataset

## Purpose
The fct_users_created dataset is a collection of data about users created in the system.

## Columns
The dataset has the following columns:
* user_id (BIGINT): The unique identifier of the user.
* created_at (TIMESTAMP): The timestamp when the user was created.
* email (STRING): The email address of the user.

## Owners
The owner of this dataset is Demo.

## Tags
The tags for this dataset are Demo.

## Lineage
The upstream lineage for this dataset is None.

## Example usage
To use this dataset, you can run the following query: