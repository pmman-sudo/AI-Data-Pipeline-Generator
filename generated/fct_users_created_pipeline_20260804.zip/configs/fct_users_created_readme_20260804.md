# README: fct_users_created Dataset
## Purpose
The `fct_users_created` dataset is designed to store information about newly created user accounts. It captures key details such as the unique identifier of the user, the timestamp when the account was created, and the user's email address. This dataset aims to provide insights into user creation trends and patterns over time.

## Columns
The `fct_users_created` dataset consists of the following columns:
- `user_id` (BIGINT): A unique identifier assigned to each user.
- `created_at` (TIMESTAMP): The timestamp when the user account was created.
- `email` (STRING): The email address associated with the user.

## Owners
The `fct_users_created` dataset is owned by **Demo**.

## Tags
This dataset is tagged with **Demo** for categorization and search purposes.

## Lineage
The `fct_users_created` dataset does not have any upstream lineage, as it is a source dataset.

## Example Usage
To gain insights from the `fct_users_created` dataset, you can perform various analyses, such as calculating the number of users created per day or identifying the most common email domains among new users. Here's an example query to get the daily count of new users: