# airflow_cfg.yml
dags:
  - name: fct_users_created_pipeline
    schedule_interval: "@daily"
    start_date: "2022-01-01"