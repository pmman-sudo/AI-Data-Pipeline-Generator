# Import necessary libraries
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.emr import EMROperator
from airflow.providers.amazon.aws.sensors.emr import EMRJobFlowSensor
from airflow.operators.dbt_operator import DbtRunOperator

# Define default arguments for the DAG
default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Define the DAG
with DAG(
    'fct_users_created_pipeline',
    default_args=default_args,
    description='A pipeline to create the fct_users_created dataset',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    tags=['Demo'],
) as dag:
    # Create a task to run the dbt model
    dbt_run = DbtRunOperator(
        task_id='dbt_run',
        dbt_bin='/usr/local/airflow/dbt',
        dbt_repo_path='/usr/local/airflow/dbt',
        dbt_model_path='models/fct_users_created.sql',
        full_refresh=True,
    )

    # Create a task to log the start of the pipeline
    log_start = BashOperator(
        task_id='log_start',
        bash_command='echo "Starting fct_users_created pipeline"',
    )

    # Create a task to log the end of the pipeline
    log_end = BashOperator(
        task_id='log_end',
        bash_command='echo "Ending fct_users_created pipeline"',
    )

    # Set the dependencies for the tasks
    log_start >> dbt_run >> log_end

# YAML configuration
config = """
---
version: '1.0'
dataset:
  name: fct_users_created
  columns:
    - user_id (BIGINT)
    - created_at (TIMESTAMP)
    - email (STRING)
  owners:
    - Demo
  tags:
    - Demo
  lineage:
    - None
"""

# IAM policy
iam_policy = """
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "AllowFctUsersCreatedAccess",
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject"
            ],
            "Resource": [
                "arn:aws:s3:::my-bucket/fct_users_created/*"
            ]
        }
    ]
}
"""

# README documentation
readme = """
# Fct Users Created Dataset
## Purpose
The fct_users_created dataset is used to store information about users who have been created.

## Columns
* user_id (BIGINT): The ID of the user
* created_at (TIMESTAMP): The timestamp when the user was created
* email (STRING): The email address of the user

## Owners
* Demo

## Tags
* Demo

## Lineage
* None

## Example usage
To use this dataset, simply query the fct_users_created table in your database.
"""