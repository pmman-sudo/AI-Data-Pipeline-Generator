# README: fct_users_created Dataset
## Purpose
The `fct_users_created` dataset is designed to store information about newly created user accounts. It captures key details such as the unique user identifier, the timestamp of account creation, and the associated email address. This dataset serves as a foundational element for analyzing user acquisition, retention, and related metrics.

## Columns
- **user_id (BIGINT)**: A unique identifier assigned to each user.
- **created_at (TIMESTAMP)**: The exact timestamp when the user account was created.
- **email (STRING)**: The email address associated with the user account.

## Owners
The `fct_users_created` dataset is owned by **Demo**.

## Tags
This dataset is tagged with **Demo** for easy identification and filtering within the data catalog.

## Lineage
The `fct_users_created` dataset does not have any upstream dependencies, making it a source dataset within our data ecosystem.

## Example Usage
To leverage this dataset for insights into user creation trends, you might query it as follows: