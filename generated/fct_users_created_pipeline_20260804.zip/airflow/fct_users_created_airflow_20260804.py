from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.transfers.s3_to_redshift import S3ToRedshiftOperator
from airflow.utils.dates import days_ago
import logging
import json

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def transform_data(**kwargs):
    """
    Transform data for fct_users_created dataset
    """
    # Define SQL transformation query
    sql_query = """
        INSERT INTO fct_users_created (user_id, created_at, email)
        SELECT user_id, created_at, email
        FROM staging_users
    """
    # Execute SQL query
    kwargs['task_instance'].xcom_push(key='sql_query', value=sql_query)

def load_data(**kwargs):
    """
    Load transformed data into fct_users_created table
    """
    sql_query = kwargs['task_instance'].xcom_pull(key='sql_query')
    # Use dbt models to load data
    dbt_command = f"dbt run --m fct_users_created --vars '{json.dumps({'sql_query': sql_query})}'"
    return dbt_command

with DAG(
    'fct_users_created_pipeline',
    default_args=default_args,
    description='A DAG to load fct_users_created dataset',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo'],
) as dag:
    # Define tasks
    transform_data_task = PythonOperator(
        task_id='transform_data',
        python_callable=transform_data,
    )
    load_data_task = BashOperator(
        task_id='load_data',
        bash_command=load_data,
    )
    # Define task dependencies
    transform_data_task >> load_data_task

    # Configure logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    # Configure monitoring
    from airflow.providers.prometheus.sensors.prometheus import PrometheusSensor
    monitoring_task = PrometheusSensor(
        task_id='monitoring',
        endpoint='query',
        query='rate(fct_users_created_inserts[1m])',
        namespace='fct_users_created',
    )
    load_data_task >> monitoring_task

    # Configure deployment
    from airflow.providers.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
    deployment_task = KubernetesPodOperator(
        task_id='deployment',
        namespace='fct_users_created',
        image='airflow/deployment:latest',
    )
    monitoring_task >> deployment_task