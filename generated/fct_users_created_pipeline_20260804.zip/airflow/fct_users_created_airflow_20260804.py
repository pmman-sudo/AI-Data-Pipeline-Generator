from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.redshift import Redshift_Run_SQL_Query
from airflow.utils.dates import days_ago
import logging
import json

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def load_fct_users_created(**kwargs):
    """
    Load data into fct_users_created table.
    """
    logging.info('Loading data into fct_users_created table')
    # Redshift connection details
    redshift_conn_id = 'redshift_default'
    # SQL query to load data
    query = """
        INSERT INTO fct_users_created (user_id, created_at, email)
        SELECT user_id, created_at, email
        FROM staging_users;
    """
    Redshift_Run_SQL_Query(
        task_id='load_fct_users_created',
        conn_id=redshift_conn_id,
        query=query
    )

def dbt_run(**kwargs):
    """
    Run DBT models.
    """
    logging.info('Running DBT models')
    # DBT command to run models
    dbt_cmd = 'dbt run --m fct_users_created'
    BashOperator(
        task_id='dbt_run',
        bash_command=dbt_cmd
    )

def yaml_config(**kwargs):
    """
    Load YAML configuration.
    """
    logging.info('Loading YAML configuration')
    with open('config.yaml', 'r') as f:
        config = yaml.safe_load(f)
    return config

dag = DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to load data into fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo']
)

load_data = PythonOperator(
    task_id='load_data',
    python_callable=load_fct_users_created,
    dag=dag
)

run_dbt = PythonOperator(
    task_id='run_dbt',
    python_callable=dbt_run,
    dag=dag
)

config_task = PythonOperator(
    task_id='config_task',
    python_callable=yaml_config,
    dag=dag
)

load_data >> run_dbt >> config_task