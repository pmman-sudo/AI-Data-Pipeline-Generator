from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.emr import EMROperator
from airflow.providers.amazon.aws.sensors.emr import EMRJobFlowSensor
from airflow.utils.dates import days_ago

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def dbt_run():
    """
    Runs dbt models to transform data.
    """
    import subprocess
    subprocess.run(["dbt", "run"], check=True)

def load_data():
    """
    Loads data into the fct_users_created table.
    """
    import pandas as pd
    from sqlalchemy import create_engine

    # Replace with your database connection string
    engine = create_engine('postgresql://user:password@host:port/dbname')

    # Replace with your data source
    data = pd.DataFrame({
        'user_id': [1, 2, 3],
        'created_at': [datetime(2022, 1, 1), datetime(2022, 1, 2), datetime(2022, 1, 3)],
        'email': ['user1@example.com', 'user2@example.com', 'user3@example.com']
    })

    data.to_sql('fct_users_created', engine, if_exists='replace', index=False)

def log_data():
    """
    Logs data for monitoring and auditing purposes.
    """
    import logging
    logging.info('Data loaded into fct_users_created table')

with DAG(
    'fct_users_created_pipeline',
    default_args=default_args,
    description='A pipeline to load data into the fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo'],
) as dag:
    dbt_task = PythonOperator(
        task_id='dbt_task',
        python_callable=dbt_run,
    )

    load_data_task = PythonOperator(
        task_id='load_data_task',
        python_callable=load_data,
    )

    log_data_task = PythonOperator(
        task_id='log_data_task',
        python_callable=log_data,
    )

    dbt_task >> load_data_task >> log_data_task