from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.log import LoggingMixin
from structlog import get_logger

logger = get_logger()

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'retry_exponential_backoff': True,
}

doc_md = """
### fct_users_created DAG
#### Description
This DAG is responsible for maintaining the fct_users_created table.
"""

def create_fct_users_created_table(**kwargs):
    """
    Create the fct_users_created table if it does not exist.
    
    :param kwargs: Airflow context
    :return: None
    """
    from airflow.providers.postgres.operators.postgres import PostgresOperator
    from airflow.hooks.postgres_hook import PostgresHook
    
    # Get the Postgres hook
    postgres_hook = PostgresHook/postgres_conn_id='my_postgres_conn')
    
    # Create the table if it does not exist
    create_table_query = """
        CREATE TABLE IF NOT EXISTS fct_users_created (
            user_id BIGINT,
            created_at TIMESTAMP,
            email STRING
        );
    """
    postgres_hook.run(create_table_query)

def load_data_into_fct_users_created_table(**kwargs):
    """
    Load data into the fct_users_created table.
    
    :param kwargs: Airflow context
    :return: None
    """
    from airflow.providers/postgres.operators.postgres import PostgresOperator
    from airflow.hooks.postgres_hook import PostgresHook
    
    # Get the Postgres hook
    postgres_hook = PostgresHook(postgres_conn_id='my_postgres_conn')
    
    # Load data into the table
    load_data_query = """
        INSERT INTO fct_users_created (user_id, created_at, email)
        VALUES (%s, %s, %s);
    """
    # Data to be loaded
    data = [(1, datetime.now(), 'user@example.com')]
    postgres_hook.run(load_data_query, parameters=data)

with DAG(
    'fct_users_created',
    default_args=default_args,
    description='fct_users_created DAG',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 12, 1),
    tags=['Demo'],
    doc_md=doc_md,
) as dag:
    create_table_task = PythonOperator(
        task_id='create_fct_users_created_table',
        python_callable=create_fct_users_created_table,
    )
    load_data_task = PythonOperator(
        task_id='load_data_into_fct_users_created_table',
        python_callable=load_data_into_fct_users_created_table,
    )
    create_table_task >> load_data_task