from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago
import logging
import json

# Define the default arguments for the DAG
default_args = {
    'owner': 'Demo',
    'tags': ['Demo'],
    'retries': 3,
    'retry_backoff': True,
    'retry_backoff_max': 300,  # 5 minutes
}

# Define the function to create the table
def create_table(**kwargs):
    """
    Creates the fct_users_created table in the database.
    
    Args:
    **kwargs: Keyword arguments passed from Airflow.
    """
    from sqlalchemy import create_engine, Column, BIGINT, TIMESTAMP, String, MetaData
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy.orm import sessionmaker
    
    # Define the database connection
    engine = create_engine('postgresql://user:password@host:port/dbname')
    
    # Define the metadata and base
    metadata = MetaData()
    Base = declarative_base(metadata=metadata)
    
    # Define the table
    class FctUsersCreated(Base):
        __tablename__ = 'fct_users_created'
        user_id = Column(BIGINT, primary_key=True)
        created_at = Column(TIMESTAMP)
        email = Column(String)
    
    # Create the table
    Base.metadata.create_all(engine)
    
    # Log the creation of the table
    logging.info('Table fct_users_created created successfully.')

# Define the function to load data into the table
def load_data(**kwargs):
    """
    Loads data into the fct_users_created table.
    
    Args:
    **kwargs: Keyword arguments passed from Airflow.
    """
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    
    # Define the database connection
    engine = create_engine('postgresql://user:password@host:port/dbname')
    
    # Create a session
    Session = sessionmaker(bind=engine)
    session = Session()
    
    # Load the data
    try:
        # Replace this with your actual data loading logic
        data = [{'user_id': 1, 'created_at': datetime.now(), 'email': 'user@example.com'}]
        for row in data:
            session.execute('INSERT INTO fct_users_created (user_id, created_at, email) VALUES (%s, %s, %s)', (row['user_id'], row['created_at'], row['email']))
        session.commit()
        logging.info('Data loaded successfully into fct_users_created table.')
    except Exception as e:
        logging.error(f'Error loading data: {str(e)}')
        session.rollback()
        raise

# Define the DAG
with DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create and load data into the fct_users_created table',
    schedule_interval=None,
    start_date=days_ago(1),
    catchup=False,
) as dag:
    # Task to create the table
    create_table_task = PythonOperator(
        task_id='create_table',
        python_callable=create_table,
    )
    
    # Task to load data into the table
    load_data_task = PythonOperator(
        task_id='load_data',
        python_callable=load_data,
    )
    
    # Dependences
    create_table_task >> load_data_task