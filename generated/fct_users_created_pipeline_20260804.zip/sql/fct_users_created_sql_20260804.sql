-- Create the fct_users_created table
CREATE TABLE fct_users_created (
    user_id BIGINT,
    created_at TIMESTAMP,
    email STRING
);

-- Insert data into the fct_users_created table
INSERT INTO fct_users_created (user_id, created_at, email)
SELECT 
    u.user_id,
    u.created_at,
    u.email
FROM 
    users u;

-- Create a view to transform the data
CREATE VIEW fct_users_created_transformed AS
SELECT 
    user_id,
    created_at,
    email
FROM 
    fct_users_created
WHERE 
    created_at IS NOT NULL
    AND email IS NOT NULL;

-- Create a dbt model to handle the transformation
{{
    config(
        materialized='table',
        alias='fct_users_created_model'
    )
}}

SELECT 
    user_id,
    created_at,
    email
FROM 
    {{ source('fct_users_created_transformed') }}

-- YAML configuration for the Airflow pipeline
---
version: '1.0'
dags:
  - name: fct_users_created_pipeline
    schedule_interval: '@daily'
    tasks:
      - task_id: create_fct_users_created_table
        bash_command: |
          CREATE TABLE fct_users_created (
              user_id BIGINT,
              created_at TIMESTAMP,
              email STRING
          );
      - task_id: insert_data_into_fct_users_created_table
        bash_command: |
          INSERT INTO fct_users_created (user_id, created_at, email)
          SELECT 
              u.user_id,
              u.created_at,
              u.email
          FROM 
              users u;
      - task_id: create_fct_users_created_transformed_view
        bash_command: |
          CREATE VIEW fct_users_created_transformed AS
          SELECT 
              user_id,
              created_at,
              email
          FROM 
              fct_users_created
          WHERE 
              created_at IS NOT NULL
              AND email IS NOT NULL;
      - task_id: create_fct_users_created_model
        bash_command: |
          {{ config(
              materialized='table',
              alias='fct_users_created_model'
          ) }}
          SELECT 
              user_id,
              created_at,
              email
          FROM 
              {{ source('fct_users_created_transformed') }}

-- IAM policy for the Airflow pipeline
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "AllowAirflowToReadWriteFctUsersCreatedTable",
            "Effect": "Allow",
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:DeleteObject"
            ],
            "Resource": "arn:aws:s3:::fct-users-created-table"
        },
        {
            "Sid": "AllowAirflowToReadWriteFctUsersCreatedTransformedView",
            "Effect": "Allow",
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:DeleteObject"
            ],
            "Resource": "arn:aws:s3:::fct-users-created-transformed-view"
        },
        {
            "Sid": "AllowAirflowToReadWriteFctUsersCreatedModel",
            "Effect": "Allow",
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:DeleteObject"
            ],
            "Resource": "arn:aws:s3:::fct-users-created-model"
        }
    ]
}

-- Logging configuration for the Airflow pipeline
{
    "version": 1,
    "formatters": {
        "simple": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        }
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "simple"
        },
        "file": {
            "class": "logging.FileHandler",
            "filename": "airflow.log",
            "formatter": "simple"
        }
    },
    "root": {
        "level": "INFO",
        "handlers": ["console", "file"]
    }
}

-- Monitoring configuration for the Airflow pipeline
{
    "version": 1,
    "metric_groups": [
        {
            "name": "fct_users_created_pipeline",
            "metrics": [
                {
                    "name": "tasks_succeeded",
                    "type": "counter",
                    "help": "Number of tasks that succeeded"
                },
                {
                    "name": "tasks_failed",
                    "type": "counter",
                    "help": "Number of tasks that failed"
                }
            ]
        }
    ]
}

-- Deployment best practices for the Airflow pipeline
1. Use a version control system to track changes to the pipeline.
2. Test the pipeline locally before deploying it to production.
3. Use a continuous integration and continuous deployment (CI/CD) pipeline to automate testing and deployment.
4. Monitor the pipeline for errors and performance issues.
5. Use a logging and monitoring system to track the pipeline's performance and troubleshoot issues.
6. Use a secure method to store and manage sensitive credentials and keys.
7. Follow security best practices to ensure the pipeline is secure and compliant with regulations.

-- Airflow DAG code
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2023, 3, 20),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'fct_users_created_pipeline',
    default_args=default_args,
    schedule_interval=timedelta(days=1),
)

create_fct_users_created_table = BashOperator(
    task_id='create_fct_users_created_table',
    bash_command='''
        CREATE TABLE fct_users_created (
            user_id BIGINT,
            created_at TIMESTAMP,
            email STRING
        );
    ''',
    dag=dag,
)

insert_data_into_fct_users_created_table = BashOperator(
    task_id='insert_data_into_fct_users_created_table',
    bash_command='''
        INSERT INTO fct_users_created (user_id, created_at, email)
        SELECT 
            u.user_id,
            u.created_at,
            u.email
        FROM 
            users u;
    ''',
    dag=dag,
)

create_fct_users_created_transformed_view = BashOperator(
    task_id='create_fct_users_created_transformed_view',
    bash_command='''
        CREATE VIEW fct_users_created_transformed AS
        SELECT 
            user_id,
            created_at,
            email
        FROM 
            fct_users_created
        WHERE 
            created_at IS NOT NULL
            AND email IS NOT NULL;
    ''',
    dag=dag,
)

create_fct_users_created_model = BashOperator(
    task_id='create_fct_users_created_model',
    bash_command='''
        {{ config(
            materialized='table',
            alias='fct_users_created_model'
        ) }}
        SELECT 
            user_id,
            created_at,
            email
        FROM 
            {{ source('fct_users_created_transformed') }}
    ''',
    dag=dag,
)

end_task = BashOperator(
    task_id='end_task',
    bash_command='echo "Pipeline finished"',
    dag=dag,
)

create_fct_users_created_table >> insert_data_into_fct_users_created_table >> create_fct_users_created_transformed_view >> create_fct_users_created_model >> end_task