SELECT 
    u.user_id,
    u.created_at,
    u.email
FROM 
    fct_users_created u;