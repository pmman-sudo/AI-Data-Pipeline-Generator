-- fct_users_created.sql

{{ config(
    materialized = 'table',
    alias = 'fct_users_created',
    schema = 'demo',
    database = 'demo_db',
    tags = ['demo'],
    owner = 'demo'
) }}

WITH users_created AS (
    SELECT 
        user_id,
        created_at,
        email
    FROM 
        stg_users
)

SELECT 
    user_id,
    created_at,
    email
FROM 
    users_created