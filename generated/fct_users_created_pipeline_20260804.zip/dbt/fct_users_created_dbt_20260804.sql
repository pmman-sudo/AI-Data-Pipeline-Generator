{{
  config(
    materialized = 'table',
    alias = 'fct_users_created'
  )
}}

WITH 
-- Define the source data using dbt's ref() function
users_source AS (
  SELECT 
    -- Cast columns to appropriate data types if necessary
    user_id::BIGINT AS user_id,
    created_at::TIMESTAMP AS created_at,
    email::STRING AS email
  FROM 
    -- Use ref() function to reference the upstream dependency
    {{ ref('stg_users') }}
)

SELECT 
  -- Select the required columns
  user_id,
  created_at,
  email
FROM 
  users_source