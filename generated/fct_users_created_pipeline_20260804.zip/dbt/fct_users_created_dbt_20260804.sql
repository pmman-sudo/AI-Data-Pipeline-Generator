{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    schema = 'demo',
    tags = ['demo']
  )
}}


WITH users AS (
  SELECT 
    user_id,
    created_at,
    email
  FROM 
    {{ ref('stg_users') }}
)

SELECT 
  CAST(user_id AS BIGINT) AS user_id,
  CAST(created_at AS TIMESTAMP) AS created_at,
  CAST(email AS STRING) AS email
FROM 
  users