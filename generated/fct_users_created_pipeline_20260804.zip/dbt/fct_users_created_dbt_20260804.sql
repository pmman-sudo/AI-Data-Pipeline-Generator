{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    tags = ['Demo'],
    owners = ['Demo']
  )
}}

WITH users AS (
  -- Upstream dependencies are not provided, assuming no upstream dependencies for demonstration purposes
  SELECT 
    user_id::BIGINT,
    created_at::TIMESTAMP,
    email::STRING
  FROM 
    {{ ref('stg_users') }}  -- Replace 'stg_users' with actual table name from upstream lineage
)

SELECT 
  user_id,
  created_at,
  email
FROM 
  users