from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.redshift import RedshiftRunQueryOperator
from airflow.utils.db import provide_session
from airflow.utils.log.LoggingMixin import LoggingMixin
from airflow.utils.log.logging_mixin import via_log
import logging

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'retry_exponential_backoff': True,
}

def create_table(**kwargs):
    """
    Create the fct_users_created table in Redshift.
    
    :param kwargs: Airflow context
    """
    query = """
        CREATE TABLE IF NOT EXISTS fct_users_created (
            user_id BIGINT,
            created_at TIMESTAMP,
            email STRING
        );
    """
    return RedshiftRunQueryOperator(task_id='create_table', query=query, **kwargs)

def insert_data(**kwargs):
    """
    Insert data into the fct_users_created table in Redshift.
    
    :param kwargs: Airflow context
    """
    query = """
        INSERT INTO fct_users_created (user_id, created_at, email)
        VALUES (1, '2022-01-01 12:00:00', 'user@example.com');
    """
    return RedshiftRunQueryOperator(task_id='insert_data', query=query, **kwargs)

def log_info(message):
    """
    Log info message.
    
    :param message: Message to log
    """
    logger = logging.getLogger(__name__)
    logger.info(message)

dag = DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='DAG for fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2022, 1, 1),
    tags=['Demo'],
)

create_table_task = PythonOperator(
    task_id='create_table',
    python_callable=create_table,
    dag=dag,
)

insert_data_task = PythonOperator(
    task_id='insert_data',
    python_callable=insert_data,
    dag=dag,
)

log_info_task = PythonOperator(
    task_id='log_info',
    python_callable=log_info,
    op_args=['Data inserted successfully'],
    dag=dag,
)

end_task = DummyOperator(
    task_id='end_task',
    trigger_rule='all_done',
    dag=dag,
)

create_table_task >> insert_data_task >> log_info_task >> end_task