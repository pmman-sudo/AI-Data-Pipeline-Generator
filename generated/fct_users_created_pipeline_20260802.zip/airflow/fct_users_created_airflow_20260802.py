from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.emr import EMROperator
from airflow.providers.amazon.aws.transfers.s3_to_redshift import S3ToRedshiftOperator
from airflow.utils.dates import days_ago
import logging

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5)
}

def dbt_run():
    """
    Run dbt model to transform data.
    """
    logging.info('Running dbt model')
    # Run dbt command
    dbt_command = 'dbt run --m fct_users_created'
    return dbt_command

def sql_transformation():
    """
    Apply SQL transformations to data.
    """
    logging.info('Applying SQL transformations')
    # Apply SQL transformations
    sql_command = 'sql_transformations.py'
    return sql_command

def load_data():
    """
    Load data into Redshift.
    """
    logging.info('Loading data into Redshift')
    # Load data into Redshift
    load_command = 'load_data.py'
    return load_command

dag = DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create the fct_users_created dataset',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo']
)

run_dbt = PythonOperator(
    task_id='run_dbt',
    python_callable=dbt_run,
    dag=dag
)

apply_sql_transformations = PythonOperator(
    task_id='apply_sql_transformations',
    python_callable=sql_transformation,
    dag=dag
)

load_data_into_redshift = PythonOperator(
    task_id='load_data_into_redshift',
    python_callable=load_data,
    dag=dag
)

end_task = BashOperator(
    task_id='end_task',
    bash_command='echo "DAG finished"',
    dag=dag
)

run_dbt >> apply_sql_transformations >> load_data_into_redshift >> end_task