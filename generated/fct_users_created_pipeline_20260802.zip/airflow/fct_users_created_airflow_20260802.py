from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
import logging

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def count_daily_active_users(**kwargs):
    """
    Counts daily active users by querying the fct_users_created table.
    
    :param kwargs: Airflow kwargs
    :return: None
    """
    import psycopg2
    from psycopg2 import Error

    try:
        # Establish a connection to the database
        conn = psycopg2.connect(
            dbname='your_database',
            user='your_username',
            password='your_password',
            host='your_host',
            port='your_port'
        )
        
        # Create a cursor object
        cur = conn.cursor()
        
        # Query to count daily active users
        query = """
            SELECT 
                DATE(created_at) AS date,
                COUNT(DISTINCT user_id) AS daily_active_users
            FROM 
                fct_users_created
            GROUP BY 
                DATE(created_at)
            ORDER BY 
                date DESC;
        """
        
        # Execute the query
        cur.execute(query)
        
        # Fetch all rows
        rows = cur.fetchall()
        
        # Close the cursor and connection
        cur.close()
        conn.close()
        
        # Log the results
        for row in rows:
            logging.info(f"Date: {row[0]}, Daily Active Users: {row[1]}")
    
    except (Exception, Error) as error:
        # Log any errors
        logging.error("Error while counting daily active users: %s", error)

with DAG(
    'count_daily_active_users',
    default_args=default_args,
    description='A DAG to count daily active users',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    tags=['Demo'],
) as dag:
    count_daily_active_users_task = PythonOperator(
        task_id='count_daily_active_users',
        python_callable=count_daily_active_users
    )
    
    end_task = PostgresOperator(
        task_id='end_task',
        conn_id='your_postgres_conn',
        sql="SELECT 'Daily active users count completed';"
    )
    
    count_daily_active_users_task >> end_task