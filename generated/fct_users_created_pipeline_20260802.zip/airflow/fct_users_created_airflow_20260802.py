from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.db import provide_session
from airflow.utils.log.logging_mixin import LoggingMixin
from airflow.utils.retries import retry_exponential_backoff

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_backoff_factor': 2,
    'retry_delay': timedelta(minutes=5),
}

def load_fct_users_created(**kwargs):
    """
    Load data into the fct_users_created table.
    
    :param kwargs: Keyword arguments
    :return: None
    """
    try:
        # Add your data loading logic here
        LoggingMixin().log.info("Loading data into fct_users_created table")
    except Exception as e:
        LoggingMixin().log.error("Error loading data: %s", e)
        raise

with DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A daily DAG to load data into the fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 12, 1),
    tags=['Demo'],
) as dag:
    load_fct_users_created_task = PythonOperator(
        task_id='load_fct_users_created',
        python_callable=load_fct_users_created,
        retries=3,
        retry_exponential_backoff=True,
    )

    end_task = DummyOperator(
        task_id='end_task',
        trigger_rule='all_done',
    )

    load_fct_users_created_task >> end_task