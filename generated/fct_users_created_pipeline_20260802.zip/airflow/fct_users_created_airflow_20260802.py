from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.db import provide_session
from airflow.utils.log.logging_mixin import LoggingMixin
from structlog import get_logger

logger = get_logger()

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'retry_exponential_backoff': True,
}

def create_fct_users_created(**kwargs):
    """
    Creates the fct_users_created table in the database.

    :param kwargs: Keyword arguments passed from Airflow
    :return: None
    """
    try:
        # Assuming a PostgreSQL database for this example
        from airflow.providers.postgres.operators.postgres import PostgresOperator
        create_table_query = """
            CREATE TABLE IF NOT EXISTS fct_users_created (
                user_id BIGINT,
                created_at TIMESTAMP,
                email STRING
            );
        """
        PostgresOperator(
            task_id='create_fct_users_created_table',
            conn_id='postgres_default',
            sql=create_table_query
        ).execute(kwargs['context'])
        logger.info('Created fct_users_created table')
    except Exception as e:
        logger.error('Error creating fct_users_created table', exc_info=e)
        raise

def insert_into_fct_users_created(**kwargs):
    """
    Inserts data into the fct_users_created table.

    :param kwargs: Keyword arguments passed from Airflow
    :return: None
    """
    try:
        # Assuming data is available in a variable named 'data'
        data = kwargs['data']
        # Assuming a PostgreSQL database for this example
        from airflow.providers.postgres.operators.postgres import PostgresOperator
        insert_query = """
            INSERT INTO fct_users_created (user_id, created_at, email)
            VALUES (%s, %s, %s);
        """
        for row in data:
            PostgresOperator(
                task_id='insert_into_fct_users_created_table',
                conn_id='postgres_default',
                sql=insert_query,
                parameters=row
            ).execute(kwargs['context'])
        logger.info('Inserted data into fct_users_created table')
    except Exception as e:
        logger.error('Error inserting data into fct_users_created table', exc_info=e)
        raise

with DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create and populate the fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    tags=['Demo'],
) as dag:
    create_table_task = PythonOperator(
        task_id='create_fct_users_created_table_task',
        python_callable=create_fct_users_created
    )
    insert_data_task = PythonOperator(
        task_id='insert_into_fct_users_created_table_task',
        python_callable=insert_into_fct_users_created
    )
    create_table_task >> insert_data_task