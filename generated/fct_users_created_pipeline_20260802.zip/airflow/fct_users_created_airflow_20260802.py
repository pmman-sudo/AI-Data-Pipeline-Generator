from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago
import logging

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def create_fct_users_created(**kwargs):
    """
    Create fct_users_created table.

    :param kwargs: Airflow context.
    :return: None
    """
    try:
        # Import necessary libraries
        import pandas as pd
        from sqlalchemy import create_engine

        # Define database connection
        engine = create_engine('postgresql://user:password@host:port/dbname')

        # Define query to fetch data
        query = """
            SELECT 
                user_id, 
                created_at, 
                email
            FROM 
                users
        """

        # Fetch data from database
        data = pd.read_sql(query, engine)

        # Create fct_users_created table
        data.to_sql('fct_users_created', engine, if_exists='replace', index=False)

        logging.info('fct_users_created table created successfully')

    except Exception as e:
        logging.error(f'Failed to create fct_users_created table: {str(e)}')
        raise

with DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create fct_users_created table',
    schedule_interval='0 0 * * *',  # Daily at midnight
    start_date=days_ago(1),
    tags=['Demo'],
) as dag:
    create_fct_users_created_task = PythonOperator(
        task_id='create_fct_users_created',
        python_callable=create_fct_users_created,
    )