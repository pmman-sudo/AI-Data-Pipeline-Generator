# airflow_pipeline.py
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.emr import EMROperator
from airflow.providers.amazon.aws.sensors.emr import EMRSensor
import boto3
import json

# Define constants
FCT_USERS_CREATED_TABLE = 'fct_users_created'
DBT_MODELS = ['users_created']
YAML_CONFIG = 'airflow_config.yaml'
IAM_POLICY = 'airflow_iam_policy.json'
README_DOC = 'README.md'
LOG_GROUP = 'airflow-logs'

# Define the DAG
default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'fct_users_created_pipeline',
    default_args=default_args,
    description='A simple pipeline for the fct_users_created dataset',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 3, 21),
    tags=['Demo'],
)

# Define the tasks
def create_dbt_models(**kwargs):
    dbt = boto3.client('dbt')
    for model in DBT_MODELS:
        dbt.create_model(
            ModelName=model,
            Schema='public',
            TableName=FCT_USERS_CREATED_TABLE,
        )

def run_sql_transformations(**kwargs):
    sql = """
        CREATE TABLE IF NOT EXISTS fct_users_created (
            user_id BIGINT,
            created_at TIMESTAMP,
            email STRING
        );
        
        INSERT INTO fct_users_created (user_id, created_at, email)
        SELECT user_id, created_at, email
        FROM src_users;
    """
    emr = boto3.client('emr')
    emr.run_job_flow(
        Name='fct_users_created_pipeline',
        LogUri=f's3://my-bucket/{LOG_GROUP}',
        ReleaseLabel='emr-6.3.0',
        Instances={
            'InstanceGroups': [
                {
                    'Name': 'MasterNode',
                    'Market': 'ON_DEMAND',
                    'InstanceType': 'm5.xlarge',
                },
            ],
        },
        Steps=[
            {
                'Name': 'Run SQL Transformations',
                'HadoopJarStep': {
                    'Jar': 'command-runner.jar',
                    'Args': [
                        'hive',
                        '-f',
                        's3://my-bucket/fct_users_created.hql',
                    ],
                },
            },
        ],
    )

def generate_readme(**kwargs):
    with open(README_DOC, 'w') as f:
        f.write('## Purpose\n')
        f.write('This dataset contains information about created users.\n')
        f.write('\n## Columns\n')
        f.write('| Column Name | Data Type | Description |\n')
        f.write('| --- | --- | --- |\n')
        f.write('| user_id | BIGINT | Unique identifier for the user. |\n')
        f.write('| created_at | TIMESTAMP | Timestamp when the user was created. |\n')
        f.write('| email | STRING | Email address of the user. |\n')
        f.write('\n## Owners\n')
        f.write('* Demo\n')
        f.write('\n## Tags\n')
        f.write('* Demo\n')
        f.write('\n## Lineage\n')
        f.write('None\n')
        f.write('\n## Example Usage\n')
        f.write('SELECT * FROM fct_users_created;')

create_dbt_models_task = PythonOperator(
    task_id='create_dbt_models',
    python_callable=create_dbt_models,
    dag=dag,
)

run_sql_transformations_task = PythonOperator(
    task_id='run_sql_transformations',
    python_callable=run_sql_transformations,
    dag=dag,
)

generate_readme_task = PythonOperator(
    task_id='generate_readme',
    python_callable=generate_readme,
    dag=dag,
)

end_task = BashOperator(
    task_id='end_task',
    bash_command='echo "Pipeline finished successfully."',
    dag=dag,
)

# Define the task dependencies
create_dbt_models_task >> run_sql_transformations_task >> generate_readme_task >> end_task