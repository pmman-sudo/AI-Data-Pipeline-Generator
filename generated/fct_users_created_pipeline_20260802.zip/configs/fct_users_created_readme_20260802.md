# README: fct_users_created Table Documentation
## Purpose
The `fct_users_created` table is designed to store information about newly created user accounts. It captures key details such as the unique identifier of the user, the timestamp when the account was created, and the user's email address.

## Columns
The `fct_users_created` table consists of the following columns:
- `user_id` (BIGINT): A unique identifier for each user.
- `created_at` (TIMESTAMP): The timestamp when the user account was created.
- `email` (STRING): The email address associated with the user account.

## Owners
The `fct_users_created` table is owned by **Demo**.

## Tags
This table is tagged with **Demo** for categorization and filtering purposes.

## Lineage
The `fct_users_created` table does not have any upstream dependencies.

## Example Usage
To retrieve the email addresses of all users created within the last 24 hours, you can use the following SQL query: