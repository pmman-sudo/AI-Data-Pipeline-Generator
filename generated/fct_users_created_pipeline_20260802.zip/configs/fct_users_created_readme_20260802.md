# README: fct_users_created Dataset
=====================================================

## Purpose
---------
The `fct_users_created` dataset is designed to store information about newly created user accounts. It provides a centralized location for tracking user creation events, enabling analysis and reporting on user acquisition and growth.

## Columns
----------
The `fct_users_created` table consists of the following columns:

* **user_id** (BIGINT): Unique identifier for each user
* **created_at** (TIMESTAMP): Timestamp when the user account was created
* **email** (STRING): Email address associated with the user account

## Owners
--------
The `fct_users_created` dataset is owned by **Demo**.

## Tags
-----
The `fct_users_created` dataset is tagged with **Demo**.

## Lineage
----------
The `fct_users_created` dataset has no upstream lineage, as it is a source table.

## Example Usage
---------------
To query the `fct_users_created` dataset and retrieve the number of users created per day, you can use the following SQL query: