from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

def generate_readme(**kwargs):
    with open('/path/to/README.md', 'w') as f:
        f.write('# fct_users_created\n')
        f.write('## Purpose\n')
        f.write('This table stores information about created users.\n')
        f.write('## Columns\n')
        f.write('| Column Name | Data Type | Description |\n')
        f.write('| --- | --- | --- |\n')
        f.write('| user_id | BIGINT | Unique user ID |\n')
        f.write('| created_at | TIMESTAMP | Timestamp when the user was created |\n')
        f.write('| email | STRING | User email |\n')
        f.write('## Owners\n')
        f.write('* Demo\n')
        f.write('## Tags\n')
        f.write('* Demo\n')
        f.write('## Lineage\n')
        f.write('None\n')
        f.write('## Example Usage\n')
        f.write('SELECT * FROM fct_users_created;')

with DAG(
    'fct_users_created',
    default_args=default_args,
    description='A DAG to create fct_users_created table',
    schedule_interval='@daily',
    start_date=datetime(2023, 12, 1),
    catchup=False,
    tags=['Demo'],
) as dag:
    create_table = PostgresOperator(
        task_id='create_table',
        conn_id='postgres_default',
        sql='''
            CREATE TABLE IF NOT EXISTS fct_users_created (
                user_id BIGINT,
                created_at TIMESTAMP,
                email STRING
            );
        '''
    )

    generate_readme_doc = PythonOperator(
        task_id='generate_readme',
        python_callable=generate_readme,
    )

    create_table >> generate_readme_doc