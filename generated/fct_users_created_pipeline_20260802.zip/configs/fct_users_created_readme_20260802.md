from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.postgres_operator import PostgresOperator

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'fct_users_created',
    default_args=default_args,
    description='A daily DAG to populate fct_users_created',
    schedule_interval='0 0 * * *',
    start_date=datetime(2023, 12, 1),
    catchup=False,
    tags=['Demo'],
)

task = PostgresOperator(
    task_id='populate_fct_users_created',
    conn_id='postgres_default',
    sql='sql/populate_fct_users_created.sql',
    dag=dag,
)