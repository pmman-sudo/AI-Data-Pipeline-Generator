SELECT 
    DATE(created_at) AS daily_date,
    COUNT(DISTINCT user_id) AS daily_active_users
FROM 
    fct_users_created
GROUP BY 
    DATE(created_at)
ORDER BY 
    daily_date;