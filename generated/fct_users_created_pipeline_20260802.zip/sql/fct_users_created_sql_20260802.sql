from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.postgres_operator import PostgresOperator

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'start_date': datetime(2023, 12, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'fct_users_created',
    default_args=default_args,
    schedule_interval='@daily',
    tags=['Demo'],
)

create_fct_users_created_table = PostgresOperator(
    task_id='create_fct_users_created_table',
    sql='''
        CREATE TABLE IF NOT EXISTS fct_users_created (
            user_id BIGINT,
            created_at TIMESTAMP,
            email STRING
        );
    ''',
    dag=dag,
)

insert_into_fct_users_created_table = PostgresOperator(
    task_id='insert_into_fct_users_created_table',
    sql='''
        INSERT INTO fct_users_created (user_id, created_at, email)
        SELECT 
            u.user_id,
            u.created_at,
            u.email
        FROM 
            users u
        WHERE 
            u.created_at >= DATE_TRUNC('day', CURRENT_DATE - INTERVAL '1 day')
            AND u.created_at < DATE_TRUNC('day', CURRENT_DATE);
    ''',
    dag=dag,
)

end_task = BashOperator(
    task_id='end_task',
    bash_command='echo "fct_users_created DAG completed"',
    dag=dag,
)

create_fct_users_created_table >> insert_into_fct_users_created_table >> end_task