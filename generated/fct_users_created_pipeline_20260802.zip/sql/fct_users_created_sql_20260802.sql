CREATE TABLE fct_users_created
(
    user_id BIGINT,
    created_at TIMESTAMP,
    email STRING
);

INSERT INTO fct_users_created (user_id, created_at, email)
SELECT 
    u.user_id,
    u.created_at,
    u.email
FROM 
    (SELECT 
         user_id,
         created_at,
         email
     FROM 
         src_users) u;