from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.postgres_operator import PostgresOperator

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'start_date': datetime(2023, 12, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'fct_users_created_dag',
    default_args=default_args,
    schedule_interval='@daily',
    tags=['Demo'],
)

fct_users_created_task = PostgresOperator(
    task_id='fct_users_created_task',
    dag=dag,
    sql='''
        INSERT INTO fct_users_created (user_id, created_at, email)
        SELECT 
            user_id,
            created_at,
            email
        FROM 
            src_users
        WHERE 
            created_at >= DATE_TRUNC('day', CURRENT_DATE - INTERVAL '1 day')
            AND created_at < DATE_TRUNC('day', CURRENT_DATE);
    ''',
)

end_task = DummyOperator(
    task_id='end_task',
    trigger_rule='all_done',
    dag=dag,
)

fct_users_created_task >> end_task