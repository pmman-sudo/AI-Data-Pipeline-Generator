SELECT 
    user_id,
    created_at,
    email
FROM 
    fct_users_created