{{
  config(
    materialized = 'table',
    alias = 'daily_active_users'
  )
}}

WITH daily_users AS (
  SELECT 
    DATE(created_at) AS date,
    user_id
  FROM 
    {{ ref('fct_users_created') }}
)

SELECT 
  date,
  COUNT(DISTINCT user_id) AS daily_active_users
FROM 
  daily_users
GROUP BY 
  date
ORDER BY 
  date DESC