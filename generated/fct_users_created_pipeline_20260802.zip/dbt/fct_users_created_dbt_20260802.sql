{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    owners = ['Demo'],
    tags = ['Demo']
  )
}}

WITH 
-- Define the source data using dbt's ref() function
users AS (
  SELECT 
    user_id,
    created_at,
    email
  FROM 
    {{ ref('users') }}
)

SELECT 
  -- Cast columns to appropriate data types if necessary
  user_id::BIGINT AS user_id,
  created_at::TIMESTAMP AS created_at,
  email::STRING AS email
FROM 
  users