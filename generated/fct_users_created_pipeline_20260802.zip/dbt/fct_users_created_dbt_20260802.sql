{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    owner = 'Demo',
    tags = ['Demo']
  )
}}

WITH 
-- Define the source tables using dbt's ref() function
users AS (
  SELECT * FROM {{ ref('users') }}
),

-- Since there are no upstream dependencies, 
-- we assume that 'users' is the only source table
created_users AS (
  SELECT 
    user_id,
    created_at,
    email
  FROM users
)

-- Select data from the created-users CTE
SELECT 
  user_id::BIGINT AS user_id,
  created_at::TIMESTAMP AS created_at,
  email::STRING AS email
FROM created_users