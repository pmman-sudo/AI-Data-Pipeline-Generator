{{
  config(
    materialized = 'table',
    schema = 'public',
    alias = 'fct_users_created'
  )
}}


WITH users AS (
  SELECT 
    user_id::BIGINT AS user_id,
    created_at::TIMESTAMP AS created_at,
    email::STRING AS email
  FROM 
    {{ ref('users') }}
)

SELECT 
  user_id,
  created_at,
  email
FROM 
  users