{#
  Description: dbt model for fct_users_created table
  Owner: Demo
  Tags: Demo
#}

{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    tags = ["Demo"],
    owner = 'Demo'
  )
}}


WITH users_data AS (
  SELECT 
    user_id::BIGINT AS user_id,
    created_at::TIMESTAMP AS created_at,
    email::STRING AS email
  FROM 
    {{ ref('source_table_name') }} -- replace 'source_table_name' with the actual source table name extracted from the lineage array
)

SELECT 
  user_id,
  created_at,
  email
FROM 
  users_data