-- Create table fct_users_created
CREATE TABLE fct_users_created (
    user_id BIGINT,
    created_at TIMESTAMP,
    email STRING
);

-- Insert data into fct_users_created
INSERT INTO fct_users_created (user_id, created_at, email)
SELECT 
    uc.user_id,
    uc.created_at,
    uc.email
FROM 
    users_created uc;