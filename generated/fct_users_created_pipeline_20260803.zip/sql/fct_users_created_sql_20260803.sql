-- Create the fct_users_created table
CREATE TABLE fct_users_created (
    user_id BIGINT,
    created_at TIMESTAMP,
    email STRING
);

-- Insert data into the fct_users_created table
INSERT INTO fct_users_created (user_id, created_at, email)
SELECT 
    u.user_id,
    u.created_at,
    u.email
FROM 
    users u;