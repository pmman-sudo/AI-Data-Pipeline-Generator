from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.hooks.base import BaseHook
from airflow.utils.db import provide_session
from airflow.models import Variable
from airflow.exceptions import AirflowException
import logging
import json

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def create_fct_users_created(**kwargs):
    """
    Create fct_users_created table using dbt models.
    """
    try:
        # Create fct_users_created table
        dbt_command = "dbt run --m fct_users_created"
        BashOperator(bash_command=dbt_command).execute(kwargs)
        logging.info("fct_users_created table created successfully")
    except AirflowException as e:
        logging.error("Error creating fct_users_created table: %s", e)

def transform_fct_users_created(**kwargs):
    """
    Transform fct_users_created table using SQL transformations.
    """
    try:
        # Define SQL transformation query
        sql_query = """
            INSERT INTO fct_users_created (user_id, created_at, email)
            SELECT user_id, created_at, email
            FROM src_users
            WHERE created_at IS NOT NULL
        """
        # Execute SQL transformation query
        hook = BaseHook.get_connection('postgres')
        conn = hook.get_conn()
        cursor = conn.cursor()
        cursor.execute(sql_query)
        conn.commit()
        cursor.close()
        conn.close()
        logging.info("fct_users_created table transformed successfully")
    except AirflowException as e:
        logging.error("Error transforming fct_users_created table: %s", e)

def load_fct_users_created(**kwargs):
    """
    Load fct_users_created table into production database.
    """
    try:
        # Define load query
        load_query = """
            INSERT INTO prod.fct_users_created (user_id, created_at, email)
            SELECT user_id, created_at, email
            FROM fct_users_created
        """
        # Execute load query
        hook = BaseHook.get_connection('postgres')
        conn = hook.get_conn()
        cursor = conn.cursor()
        cursor.execute(load_query)
        conn.commit()
        cursor.close()
        conn.close()
        logging.info("fct_users_created table loaded successfully")
    except AirflowException as e:
        logging.error("Error loading fct_users_created table: %s", e)

with DAG(
    'fct_users_created_pipeline',
    default_args=default_args,
    description='A pipeline to create and load fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    tags=['Demo'],
) as dag:
    create_fct_users_created_task = PythonOperator(
        task_id='create_fct_users_created',
        python_callable=create_fct_users_created,
    )
    transform_fct_users_created_task = PythonOperator(
        task_id='transform_fct_users_created',
        python_callable=transform_fct_users_created,
    )
    load_fct_users_created_task = PythonOperator(
        task_id='load_fct_users_created',
        python_callable=load_fct_users_created,
    )

    create_fct_users_created_task >> transform_fct_users_created_task >> load_fct_users_created_task