from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.sql import AWS SQLOperator
from airflow.providers.amazon.aws.transfers.sql import SQLTransfer
from airflow.hooks.base import BaseHook
import logging

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def create_fct_users_created(**kwargs):
    """
    Create fct_users_created table and apply transformations.
    """
    try:
        # Connect to database
        conn = BaseHook.get_connection('aws_default')
        db_host = conn.host
        db_username = conn.login
        db_password = conn.password
        db_name = conn.schema

        # SQL query to create table and apply transformations
        sql_query = """
            CREATE TABLE IF NOT EXISTS fct_users_created (
                user_id BIGINT,
                created_at TIMESTAMP,
                email STRING
            );

            INSERT INTO fct_users_created (user_id, created_at, email)
            SELECT user_id, created_at, email
            FROM dim_users;
        """

        # Apply SQL query
        AWS_SQLOperator(
            task_id='create_fct_users_created',
            conn_id='aws_default',
            sql=sql_query,
            database=db_name
        )

        logging.info("fct_users_created table created and transformations applied successfully.")
    except Exception as e:
        logging.error(f"Error creating fct_users_created table and applying transformations: {str(e)}")

def load_fct_users_created(**kwargs):
    """
    Load data into fct_users_created table.
    """
    try:
        # Connect to database
        conn = BaseHook.get_connection('aws_default')
        db_host = conn.host
        db_username = conn.login
        db_password = conn.password
        db_name = conn.schema

        # SQL query to load data
        sql_query = """
            INSERT INTO fct_users_created (user_id, created_at, email)
            SELECT user_id, created_at, email
            FROM staging_users;
        """

        # Load data
        AWS_SQLOperator(
            task_id='load_fct_users_created',
            conn_id='aws_default',
            sql=sql_query,
            database=db_name
        )

        logging.info("Data loaded into fct_users_created table successfully.")
    except Exception as e:
        logging.error(f"Error loading data into fct_users_created table: {str(e)}")

dag = DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create and load fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    tags=['Demo'],
)

create_table_task = PythonOperator(
    task_id='create_fct_users_created',
    python_callable=create_fct_users_created,
    dag=dag
)

load_data_task = PythonOperator(
    task_id='load_fct_users_created',
    python_callable=load_fct_users_created,
    dag=dag
)

end_task = DummyOperator(
    task_id='end_task',
    trigger_rule='all_done',
    dag=dag
)

create_table_task >> load_data_task >> end_task