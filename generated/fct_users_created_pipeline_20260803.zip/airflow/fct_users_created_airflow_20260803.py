from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
import logging

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),  # exponential backoff
}

def create_fct_users_created_table(**kwargs):
    """
    Create the fct_users_created table.

    :param kwargs: Airflow keyword arguments
    :return: None
    """
    # Assuming we have a function to create the table
    # For this example, we'll use a placeholder function
    from sqlalchemy import create_engine
    engine = create_engine('postgresql://user:password@host:port/dbname')
    with engine.connect() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS fct_users_created (
                user_id BIGINT,
                created_at TIMESTAMP,
                email STRING
            );
        """)

def load_data_into_fct_users_created_table(**kwargs):
    """
    Load data into the fct_users_created table.

    :param kwargs: Airflow keyword arguments
    :return: None
    """
    # Assuming we have a function to load data into the table
    # For this example, we'll use a placeholder function
    from sqlalchemy import create_engine
    engine = create_engine('postgresql://user:password@host:port/dbname')
    with engine.connect() as connection:
        # Placeholder data loading logic
        connection.execute("""
            INSERT INTO fct_users_created (user_id, created_at, email)
            VALUES (1, '2022-01-01 00:00:00', 'user@example.com');
        """)

dag = DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create and load data into the fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2022, 1, 1),
    tags=['Demo'],
)

create_table = PythonOperator(
    task_id='create_fct_users_created_table',
    python_callable=create_fct_users_created_table,
    dag=dag,
)

load_data = PythonOperator(
    task_id='load_data_into_fct_users_created_table',
    python_callable=load_data_into_fct_users_created_table,
    dag=dag,
)

end_task = BashOperator(
    task_id='end_task',
    bash_command='echo "DAG completed successfully!"',
    dag=dag,
)

create_table >> load_data >> end_task