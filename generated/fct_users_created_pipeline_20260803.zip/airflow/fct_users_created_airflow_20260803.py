from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.emr import EMROperator
from airflow.providers.amazon.aws.sensors.emr import EMRJobFlowSensor
import logging
import json

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def create_fct_users_created(**kwargs):
    """
    Create the fct_users_created table using dbt.
    """
    logging.info('Creating fct_users_created table')
    dbt_command = f'dbt run --m fct_users_created'
    kwargs['task_instance'].xcom_push(key='dbt_command', value=dbt_command)

def run_dbt(**kwargs):
    """
    Run the dbt command to create the fct_users_created table.
    """
    dbt_command = kwargs['task_instance'].xcom_pull(key='dbt_command')
    logging.info(f'Running dbt command: {dbt_command}')
    BashOperator(bash_command=dbt_command)

def load_data(**kwargs):
    """
    Load the data into the fct_users_created table.
    """
    logging.info('Loading data into fct_users_created table')
    # Assuming the data is in a CSV file
    load_command = f'aws s3 cp s3://demo-bucket/data.csv s3://demo-bucket/data.csv'
    BashOperator(bash_command=load_command)

def transform_data(**kwargs):
    """
    Transform the data in the fct_users_created table using SQL.
    """
    logging.info('Transforming data in fct_users_created table')
    # Assuming the transformation is a SQL query
    transformation_query = """
        INSERT INTO fct_users_created (user_id, created_at, email)
        SELECT user_id, created_at, email
        FROM src_users
        WHERE created_at > NOW() - INTERVAL '1 day'
    """
    BashOperator(bash_command=f"psql -d demo_database -c '{transformation_query}'")

with DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create and load the fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    tags=['Demo'],
) as dag:
    create_fct_users_created_task = PythonOperator(
        task_id='create_fct_users_created',
        python_callable=create_fct_users_created,
    )
    run_dbt_task = PythonOperator(
        task_id='run_dbt',
        python_callable=run_dbt,
    )
    load_data_task = PythonOperator(
        task_id='load_data',
        python_callable=load_data,
    )
    transform_data_task = PythonOperator(
        task_id='transform_data',
        python_callable=transform_data,
    )

    create_fct_users_created_task >> run_dbt_task >> load_data_task >> transform_data_task