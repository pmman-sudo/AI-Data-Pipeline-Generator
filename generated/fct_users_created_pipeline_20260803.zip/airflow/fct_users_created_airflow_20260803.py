from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.emr import EMROperator
from airflow.providers.amazon.aws.sensors.emr import EMRJobFlowSensor
from airflow.utils.dates import days_ago
import logging
import json

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def transform_data(**kwargs):
    """
    SQL transformations for the fct_users_created dataset.
    """
    # Define the SQL query
    sql_query = """
        SELECT 
            user_id,
            created_at,
            email
        FROM 
            staging_users
    """

    # Log the query
    logging.info(sql_query)

    # Execute the query
    # For this example, we'll assume we have a function to execute the query
    # In a real-world scenario, you would use a library like psycopg2 or sqlalchemy
    results = execute_query(sql_query)

    # Log the results
    logging.info(results)

    return results

def load_data(**kwargs):
    """
    Load the transformed data into the fct_users_created table.
    """
    # Define the load query
    load_query = """
        INSERT INTO fct_users_created (user_id, created_at, email)
        VALUES (%s, %s, %s)
    """

    # Log the query
    logging.info(load_query)

    # Execute the query
    # For this example, we'll assume we have a function to execute the query
    # In a real-world scenario, you would use a library like psycopg2 or sqlalchemy
    execute_load_query(load_query, kwargs['results'])

def execute_query(sql_query):
    # This is a placeholder for your actual query execution function
    # You would replace this with your actual database connection and query execution code
    pass

def execute_load_query(load_query, results):
    # This is a placeholder for your actual load query execution function
    # You would replace this with your actual database connection and query execution code
    pass

dag = DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to transform and load the fct_users_created dataset',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo'],
)

transform_task = PythonOperator(
    task_id='transform_data',
    python_callable=transform_data,
    dag=dag,
)

load_task = PythonOperator(
    task_id='load_data',
    python_callable=load_data,
    dag=dag,
)

end_task = BashOperator(
    task_id='end_task',
    bash_command='echo "DAG finished executing]',
    dag=dag,
)

transform_task >> load_task >> end_task