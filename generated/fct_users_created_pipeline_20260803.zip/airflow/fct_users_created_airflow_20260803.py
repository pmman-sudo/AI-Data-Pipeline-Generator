from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.transfers.redshift import RedshiftOperator
import logging
import json

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def create_fct_users_created(**kwargs):
    """
    Creates the fct_users_created table in Redshift.
    
    :param kwargs: Keyword arguments
    :return: None
    """
    try:
        # Define the Redshift connection
        redshift_conn_id = 'redshift_default'
        
        # Define the SQL query to create the table
        create_table_sql = """
            CREATE TABLE IF NOT EXISTS fct_users_created (
                user_id BIGINT,
                created_at TIMESTAMP,
                email STRING
            );
        """
        
        # Execute the SQL query
        RedshiftOperator(
            task_id='create_fct_users_created',
            conn_id=redshift_conn_id,
            sql=create_table_sql
        ).execute(kwargs)
        
        logging.info("Created fct_users_created table successfully")
    
    except Exception as e:
        logging.error(f"Failed to create fct_users_created table: {str(e)}")
        raise

def insert_data_into_fct_users_created(**kwargs):
    """
    Inserts data into the fct_users_created table in Redshift.
    
    :param kwargs: Keyword arguments
    :return: None
    """
    try:
        # Define the Redshift connection
        redshift_conn_id = 'redshift_default'
        
        # Define the SQL query to insert data
        insert_data_sql = """
            INSERT INTO fct_users_created (user_id, created_at, email)
            VALUES (1, '2022-01-01 00:00:00', 'user@example.com');
        """
        
        # Execute the SQL query
        RedshiftOperator(
            task_id='insert_data_into_fct_users_created',
            conn_id=redshift_conn_id,
            sql=insert_data_sql
        ).execute(kwargs)
        
        logging.info("Inserted data into fct_users_created table successfully")
    
    except Exception as e:
        logging.error(f"Failed to insert data into fct_users_created table: {str(e)}")
        raise

with DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create and populate the fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2022, 1, 1),
    tags=['Demo'],
) as dag:
    create_table = PythonOperator(
        task_id='create_fct_users_created_table',
        python_callable=create_fct_users_created
    )
    
    insert_data = PythonOperator(
        task_id='insert_data_into_fct_users_created_table',
        python_callable=insert_data_into_fct_users_created
    )
    
    create_table >> insert_data