# fct_users_created README Documentation
## Purpose
The `fct_users_created` table is designed to store information about newly created user accounts. It captures the unique identifier of each user, the timestamp when the account was created, and the email address associated with the account.

## Columns
The `fct_users_created` table consists of the following columns:
- **user_id (BIGINT)**: A unique identifier for each user.
- **created_at (TIMESTAMP)**: The timestamp when the user account was created.
- **email (STRING)**: The email address associated with the user account.

## Owners
The `fct_users_created` table is owned by **Demo**.

## Tags
This table is tagged with **Demo** for categorization and filtering purposes.

## Lineage
The `fct_users_created` table does not have any upstream lineage, as it is a source table for user creation data.

## Example Usage
To query the number of users created per day, you can use the following SQL example: