from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'start_date': days_ago(1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'fct_users_created',
    default_args=default_args,
    schedule_interval=timedelta(days=1),
)

def dbt_model(**kwargs):
    """
    Run dbt model to transform data
    """
    import subprocess
    subprocess.run(['dbt', 'run', '--m', 'fct_users_created'], check=True)

def sql_transformation(**kwargs):
    """
    SQL transformation to create fct_users_created dataset
    """
    from sqlalchemy import create_engine
    engine = create_engine('postgresql://user:password@host:port/dbname')
    with engine.connect() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS fct_users_created (
                user_id BIGINT,
                created_at TIMESTAMP,
                email STRING
            );
        """)

def yaml_config(**kwargs):
    """
    YAML configuration for fct_users_created dataset
    """
    import yaml
    with open('config.yaml', 'r') as file:
        config = yaml.safe_load(file)
    return config

def iam_policy(**kwargs):
    """
    IAM policy for fct_users_created dataset
    """
    import boto3
    iam = boto3.client('iam')
    iam.put_policy(
        PolicyName='fct_users_created_policy',
        PolicyDocument={
            'Version': '2012-10-17',
            'Statement': [
                {
                    'Sid': 'AllowFctUsersCreatedAccess',
                    'Effect': 'Allow',
                    'Action': 's3:GetObject',
                    'Resource': 'arn:aws:s3:::bucket-name/fct_users_created'
                }
            ]
        }
    )

def logging_function(**kwargs):
    """
    Logging function for fct_users_created dataset
    """
    import logging
    logging.basicConfig(filename='fct_users_created.log', level=logging.INFO)
    logging.info('fct_users_created dataset pipeline started')

def monitoring_function(**kwargs):
    """
    Monitoring function for fct_users_created dataset
    """
    import prometheus_client
    prometheus_client.start_http_server(8000)

def example_usage(**kwargs):
    """
    Example usage of fct_users_created dataset
    """
    import pandas as pd
    df = pd.read_csv('fct_users_created.csv')
    print(df.head())

t1 = BashOperator(
    task_id='dbt_model',
    bash_command='dbt run --m fct_users_created',
    dag=dag
)

t2 = PythonOperator(
    task_id='sql_transformation',
    python_callable=sql_transformation,
    dag=dag
)

t3 = PythonOperator(
    task_id='yaml_config',
    python_callable=yaml_config,
    dag=dag
)

t4 = PythonOperator(
    task_id='iam_policy',
    python_callable=iam_policy,
    dag=dag
)

t5 = PythonOperator(
    task_id='logging_function',
    python_callable=logging_function,
    dag=dag
)

t6 = PythonOperator(
    task_id='monitoring_function',
    python_callable=monitoring_function,
    dag=dag
)

t7 = PythonOperator(
    task_id='example_usage',
    python_callable=example_usage,
    dag=dag
)

end_task = BashOperator(
    task_id='end_task',
    bash_command='echo "fct_users_created dataset pipeline finished"',
    dag=dag
)

t1 >> t2 >> t3 >> t4 >> t5 >> t6 >> t7 >> end_task