{{
  config(
    materialized = 'table',
    alias = 'fct_users_created'
  )
}}

SELECT 
  user_id,
  created_at,
  email
FROM 
  src_users