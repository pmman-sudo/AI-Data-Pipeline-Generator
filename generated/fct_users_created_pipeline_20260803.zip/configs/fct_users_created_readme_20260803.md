# README: fct_users_created Dataset
=====================================================

## Purpose
-----------
The `fct_users_created` dataset is designed to store information about newly created users. It captures key details such as the unique identifier of the user, the timestamp when the user account was created, and the user's email address. This dataset serves as a central repository for user creation data, facilitating analytics, reporting, and compliance activities.

## Columns
---------
The `fct_users_created` dataset consists of the following columns:

* **user_id (BIGINT)**: A unique identifier for each user.
* **created_at (TIMESTAMP)**: The timestamp when the user account was created.
* **email (STRING)**: The email address associated with the user.

## Owners
--------
The `fct_users_created` dataset is owned by **Demo**.

## Tags
-----
This dataset is tagged with **Demo** for categorization and search purposes.

## Lineage
---------
The `fct_users_created` dataset does not have any upstream lineage, as it is a source dataset.

## Example Usage
-------------
To leverage the `fct_users_created` dataset, you can query it to gain insights into user creation trends, such as the number of users created per day or the distribution of users by email domain. For instance: