{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    tags = ['Demo'],
    schema = 'public'
  )
}}

WITH users AS (
  SELECT 
    user_id,
    created_at,
    email
  FROM 
    {{ ref('stg_users') }}
),

created_users AS (
  SELECT 
    user_id,
    MIN(created_at) AS created_at,
    email
  FROM 
    users
  GROUP BY 
    user_id, email
)

SELECT 
  user_id::BIGINT AS user_id,
  created_at::TIMESTAMP AS created_at,
  email::VARCHAR AS email
FROM 
  created_users