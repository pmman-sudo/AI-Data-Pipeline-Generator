{{
  config(
    alias = 'fct_users_created',
    schema = 'public',
    tags = ['Demo']
  )
}}

WITH 
-- Define the source tables using ref() function for upstream dependencies
users AS (
  SELECT 
    user_id,
    created_at,
    email
  FROM 
    {{ ref('stg_users') }}  -- Assuming stg_users is the upstream dependency
)

SELECT 
  -- Cast columns to appropriate data types if necessary
  user_id::BIGINT AS user_id,
  created_at::TIMESTAMP AS created_at,
  email::STRING AS email

FROM 
  users