{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    schema = 'public',
    database = 'demo_database'
  )
}}


WITH users AS (
  SELECT 
    user_id,
    created_at,
    email
  FROM 
    {{ ref('stg_users') }}
),

transformed_users AS (
  SELECT 
    user_id::BIGINT AS user_id,
    created_at::TIMESTAMP AS created_at,
    email::STRING AS email
  FROM 
    users
)

SELECT 
  user_id,
  created_at,
  email
FROM 
  transformed_users