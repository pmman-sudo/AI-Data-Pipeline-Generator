{{
  config(
    materialized = 'table',
    alias = 'fct_users_created'
  )
}}

WITH 
-- Since there are no upstream dependencies, we will assume a source table named 'stg_users'
users AS (
  SELECT 
    user_id::BIGINT AS user_id,
    created_at::TIMESTAMP AS created_at,
    email::VARCHAR AS email
  FROM {{ ref('stg_users') }}
)

SELECT 
  user_id,
  created_at,
  email
FROM users