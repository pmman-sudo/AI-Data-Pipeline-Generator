{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    schema = 'demo',
    tags = ['demo']
  )
}}


WITH users AS (
  SELECT 
    user_id,
    created_at,
    email
  FROM 
    {{ ref('stg_users') }}
)

SELECT 
  user_id::BIGINT AS user_id,
  created_at::TIMESTAMP AS created_at,
  email::STRING AS email
FROM 
  users