{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    owner = 'Demo',
    tags = ['Demo']
  )
}}

WITH 
-- Define the source tables using dbt's ref() function
users AS (
  SELECT * FROM {{ ref('users') }}
),

-- Since there are no upstream dependencies, we will use a single source table
-- In a real-world scenario, you would replace 'users' with the actual table name extracted from the lineage array
created_users AS (
  SELECT 
    user_id,
    created_at,
    email
  FROM 
    users
)

-- Select the required columns and cast to appropriate data types if necessary
SELECT 
  user_id::BIGINT AS user_id,
  created_at::TIMESTAMP AS created_at,
  email::STRING AS email
FROM 
  created_users