{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    owners = ['Demo'],
    tags = ['Demo']
  )
}}


WITH users AS (
  -- Extract table names from upstream lineage
  SELECT * FROM {{ ref('stg_users') }}
),

created_users AS (
  SELECT 
    user_id,
    created_at,
    email
  FROM users
)

SELECT 
  -- Cast columns to appropriate data types if necessary
  user_id::BIGINT AS user_id,
  created_at::TIMESTAMP AS created_at,
  email::STRING AS email
FROM created_users