{{
  config(
    materialized = 'table',
    alias = 'fct_users_created_daily',
    owner = 'Demo',
    tags = ['Demo']
  )
}}

WITH daily_users AS (
  SELECT 
    DATE(created_at) AS created_date,
    COUNT(DISTINCT user_id) AS new_users
  FROM 
    {{ ref('fct_users_created') }}
  GROUP BY 
    DATE(created_at)
)

SELECT 
  created_date,
  new_users
FROM 
  daily_users