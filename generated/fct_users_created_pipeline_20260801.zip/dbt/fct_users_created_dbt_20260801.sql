{{
  config(
    materialized = 'table',
    alias = 'fct_users_created',
    tags = ['Demo']
  )
}}

WITH users AS (
  -- Upstream dependencies are not provided, assuming no upstream dependencies
  SELECT 
    user_id::BIGINT,
    created_at::TIMESTAMP,
    email::STRING
  FROM 
    {{ ref('stg_users') }}  -- assuming stg_users is the source table
)

SELECT 
  user_id,
  created_at,
  email
FROM 
  users