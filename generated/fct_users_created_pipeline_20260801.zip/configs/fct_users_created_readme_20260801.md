# README Documentation for fct_users_created Table
## Purpose
The fct_users_created table is designed to store information about newly created user accounts. This dataset aims to provide insights into user creation trends and patterns.

## Columns
The fct_users_created table contains the following columns:
- **user_id (BIGINT)**: A unique identifier for each user.
- **created_at (TIMESTAMP)**: The timestamp when the user account was created.
- **email (STRING)**: The email address associated with the user account.

## Owners
The owners of this dataset are:
- **Demo**

## Tags
This dataset is associated with the following tags:
- **Demo**

## Lineage
This dataset has no upstream lineage, meaning it is a source dataset and does not rely on any other datasets for its creation.

## Example Usage
To get the number of users created per day, you can use the following query: