# README Documentation for fct_users_created Table
## Purpose
The fct_users_created table is designed to store information about users at the time of their creation. This includes a unique identifier for each user, the timestamp when the user account was created, and the user's email address. The primary purpose of this table is to maintain a historical record of user creation events.

## Columns
| Column Name | Data Type | Description |
| --- | --- | --- |
| user_id | BIGINT | Unique identifier for each user |
| created_at | TIMESTAMP | Timestamp when the user account was created |
| email | STRING | Email address associated with the user |

## Owners
The owners of this dataset are:
- Demo

## Tags
The tags associated with this dataset are:
- Demo

## Lineage
This dataset does not have any upstream lineage, meaning it is not derived from any other datasets.

## Example Usage
To query the total number of users created per day, you can use the following SQL query: