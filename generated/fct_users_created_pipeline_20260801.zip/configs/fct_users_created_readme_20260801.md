# README: fct_users_created Dataset
## Purpose
The fct_users_created dataset is designed to store information about newly created user accounts. It provides a centralized location for tracking user creation events, enabling analytics and insights into user growth and acquisition.

## Columns
The dataset consists of the following columns:
* **user_id (BIGINT)**: Unique identifier for each user
* **created_at (TIMESTAMP)**: Timestamp when the user account was created
* **email (STRING)**: Email address associated with the user account

## Owners
The owners of this dataset are:
* **Demo**

## Tags
The dataset is tagged with:
* **Demo**

## Lineage
This dataset has no upstream lineage, as it is a source table for user creation events.

## Example Usage
To get the total number of users created per day, you can use the following query: