from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
import logging

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def count_new_users(**kwargs):
    """
    Counts new users created each day.
    
    :param kwargs: Airflow context
    """
    try:
        # Initialize the database connection
        from airflow.providers.postgres.hooks.postgres import PostgresHook
        postgres_hook = PostgresHook(postgres_conn_id='your_postgres_conn_id')
        conn = postgres_hook.get_conn()
        cursor = conn.cursor()
        
        # Count new users created each day
        cursor.execute("""
            SELECT 
                DATE(created_at) AS creation_date,
                COUNT(user_id) AS num_new_users
            FROM 
                fct_users_created
            GROUP BY 
                DATE(created_at)
            ORDER BY 
                creation_date DESC;
        """)
        
        # Fetch and log the results
        results = cursor.fetchall()
        for row in results:
            logging.info(f"Date: {row[0]}, New Users: {row[1]}")
        
        # Close the database connection
        cursor.close()
        conn.close()
        
    except Exception as e:
        logging.error(f"Error counting new users: {e}")

with DAG(
    'count_new_users',
    default_args=default_args,
    description='A DAG to count new users created each day',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    tags=['Demo'],
) as dag:
    count_new_users_task = PythonOperator(
        task_id='count_new_users',
        python_callable=count_new_users,
    )

    end_task = PostgresOperator(
        task_id='end_task',
        conn_id='your_postgres_conn_id',
        sql='SELECT 1;',
    )

    count_new_users_task >> end_task