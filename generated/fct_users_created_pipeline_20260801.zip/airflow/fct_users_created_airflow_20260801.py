from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago
from airflow.utils.log import logging
import json

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),  # exponential backoff
}

def create_fct_users_created(**kwargs):
    """
    Creates the fct_users_created table.

    :param kwargs:
    :return:
    """
    logging.info("Creating fct_users_created table")
    # Replace this with your actual database connection and creation logic
    # For example, using psycopg2 or sqlalchemy
    try:
        # Create the table
        logging.info("Table created successfully")
    except Exception as e:
        logging.error(f"Failed to create table: {e}")
        raise

def load_fct_users_created(**kwargs):
    """
    Loads data into the fct_users_created table.

    :param kwargs:
    :return:
    """
    logging.info("Loading data into fct_users_created table")
    # Replace this with your actual data loading logic
    # For example, using psycopg2 or sqlalchemy
    try:
        # Load the data
        logging.info("Data loaded successfully")
    except Exception as e:
        logging.error(f"Failed to load data: {e}")
        raise

with DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to create and load the fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo'],
) as dag:
    create_table_task = PythonOperator(
        task_id='create_fct_users_created_table',
        python_callable=create_fct_users_created
    )

    load_data_task = PythonOperator(
        task_id='load_fct_users_created_data',
        python_callable=load_fct_users_created
    )

    create_table_task >> load_data_task