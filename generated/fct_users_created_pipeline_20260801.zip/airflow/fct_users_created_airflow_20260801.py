from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago
from airflow.utils.email import send_email
from datetime import datetime, timedelta
import logging
import json

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'retry_exponential_backoff': True
}

dag = DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to manage the fct_users_created table',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo']
)

def extract_data(**kwargs):
    """
    Extract data from the source and load it into the fct_users_created table.
    
    :param kwargs: Context variables passed in from Airflow
    :return: None
    """
    try:
        # Replace this with your actual data extraction and loading logic
        logging.info('Extracting data...')
        # Simulating data extraction and loading for demonstration purposes
        data = [
            {'user_id': 1, 'created_at': datetime.now(), 'email': 'user1@example.com'},
            {'user_id': 2, 'created_at': datetime.now(), 'email': 'user2@example.com'}
        ]
        logging.info('Loading data into fct_users_created table...')
        # Simulating data loading for demonstration purposes
        for row in data:
            logging.info(f'Loaded user {row["user_id"]} with email {row["email"]}')
    except Exception as e:
        logging.error(f'Error extracting or loading data: {str(e)}')
        raise

def transform_data(**kwargs):
    """
    Transform the data in the fct_users_created table.
    
    :param kwargs: Context variables passed in from Airflow
    :return: None
    """
    try:
        # Replace this with your actual data transformation logic
        logging.info('Transforming data...')
        # Simulating data transformation for demonstration purposes
        logging.info('No transformation needed for this example')
    except Exception as e:
        logging.error(f'Error transforming data: {str(e)}')
        raise

def load_data(**kwargs):
    """
    Load the transformed data into the target system.
    
    :param kwargs: Context variables passed in from Airflow
    :return: None
    """
    try:
        # Replace this with your actual data loading logic
        logging.info('Loading data into target system...')
        # Simulating data loading for demonstration purposes
        logging.info('No loading needed for this example')
    except Exception as e:
        logging.error(f'Error loading data: {str(e)}')
        raise

extract_task = PythonOperator(
    task_id='extract_data',
    python_callable=extract_data,
    dag=dag
)

transform_task = PythonOperator(
    task_id='transform_data',
    python_callable=transform_data,
    dag=dag
)

load_task = PythonOperator(
    task_id='load_data',
    python_callable=load_data,
    dag=dag
)

end_task = BashOperator(
    task_id='end_task',
    bash_command='echo "DAG finished execution"',
    dag=dag
)

extract_task >> transform_task >> load_task >> end_task