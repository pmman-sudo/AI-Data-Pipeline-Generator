from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.redshift import RedshiftRunQueryOperator
from airflow.providers.amazon.aws.transfers.redshift import RedshiftOperator
from airflow.utils.dates import days_ago
import logging

default_args = {
    'owner': 'Demo',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def create_table(redshift_conn_id, table_name):
    """
    Create the fct_users_created table in Redshift.

    Args:
    - redshift_conn_id (str): The connection ID for the Redshift cluster.
    - table_name (str): The name of the table to create.

    Returns:
    - None
    """
    create_table_query = f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            user_id BIGINT,
            created_at TIMESTAMP,
            email STRING
        );
    """
    RedshiftOperator(
        task_id='create_table',
        conn_id=redshift_conn_id,
        query=create_table_query
    ).execute()

def log_task(task_id, **kwargs):
    """
    Log task information using the Airflow logging mechanism.

    Args:
    - task_id (str): The ID of the task.
    - **kwargs: Additional keyword arguments passed to the task.

    Returns:
    - None
    """
    logging.info(f'Task {task_id} executed.')

dag = DAG(
    'fct_users_created_dag',
    default_args=default_args,
    description='A DAG to manage the fct_users_created table.',
    schedule_interval=timedelta(days=1),
    start_date=days_ago(1),
    tags=['Demo'],
)

create_table_task = PythonOperator(
    task_id='create_table_task',
    python_callable=create_table,
    op_kwargs={
        'redshift_conn_id': 'redshift_default',
        'table_name': 'fct_users_created'
    },
    dag=dag
)

log_task = PythonOperator(
    task_id='log_task',
    python_callable=log_task,
    op_kwargs={
        'task_id': 'create_table_task'
    },
    dag=dag
)

create_table_task >> log_task